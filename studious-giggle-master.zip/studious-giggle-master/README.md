# studious-giggle
Included in this repository is the R code I used to clean up and pre-process:
1. a microarray data file and a 
2. patient sample annotation file

The complete code is broken down into 3 parts.
Each part includes an aim descripion.

Use my code to help you on your coding and if you have them, offer suggestions for making my code more efficient.

Be constructive! 

Please and thank you ~
